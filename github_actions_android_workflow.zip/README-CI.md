# CI de Android (GitHub Actions)

Este flujo construye el APK **debug** en cada push a `main/master` y permite (opcionalmente) firmar el **release** si configuras secretos.

## Cómo usar

1. Sube tu proyecto Android (el que te entregué, carpeta `PizarraAndroid`) a un repositorio de GitHub.
2. Copia la carpeta `.github/workflows/` a tu repo (o añade este archivo).
3. Haz push. En la pestaña **Actions** verás correr el workflow. Al finalizar, descarga:
   - `app-debug-apk` → APK debug
   - `app-release-apk` → APK release (si se construyó)

## Firma opcional de Release

Crea un keystore (una vez):
```bash
keytool -genkeypair -v -keystore pizarra-keystore.jks -storetype JKS -keyalg RSA -keysize 2048 -validity 36500 -alias pizarra
```

Convierte el keystore a Base64:
```bash
base64 pizarra-keystore.jks > keystore.b64
```

En GitHub → **Settings → Secrets and variables → Actions → New repository secret**, agrega:
- `KEYSTORE_BASE64` → contenido de `keystore.b64`
- `KEYSTORE_PASSWORD` → contraseña del keystore
- `KEY_ALIAS` → alias (ej. `pizarra`)
- `KEY_PASSWORD` → contraseña de la clave

El flujo creará `keystore.jks`, inyectará credenciales en `~/.gradle/gradle.properties` y ejecutará `assembleRelease`.

> Si tu `app/build.gradle` aún no tiene `signingConfigs`, el release saldrá **sin firmar** (igual se sube). Si quieres, te paso un `build.gradle` con firma condicional lista.
